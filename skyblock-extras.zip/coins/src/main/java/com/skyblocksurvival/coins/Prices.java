package com.skyblocksurvival.coins;

import com.google.gson.reflect.TypeToken;
import com.skyblocksurvival.PlayerStats;
import com.skyblocksurvival.SkyData;
import com.skyblocksurvival.SkyItems;
import net.minecraft.world.item.ItemStack;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Sell prices (coins per item) from config/skyblockcoins/prices.json.
 * Enchanted items that are not listed cost what their crafting ingredients cost.
 */
public final class Prices {
    private static final Map<String, Double> TABLE = new LinkedHashMap<>();
    private static final Map<String, Double> DERIVED = new HashMap<>();

    private static Map<String, Double> defaults() {
        Map<String, Double> m = new LinkedHashMap<>();
        String[][] p = {
                {"cobblestone", "0.5"}, {"stone", "1"}, {"coal", "2"}, {"charcoal", "2"}, {"iron_ingot", "3"},
                {"gold_ingot", "4"}, {"diamond", "8"}, {"emerald", "6"}, {"lapis_lazuli", "1.5"}, {"redstone", "1"},
                {"quartz", "2"}, {"obsidian", "3"}, {"glowstone_dust", "2"}, {"gravel", "0.5"}, {"flint", "1"},
                {"sand", "0.5"}, {"red_sand", "0.5"}, {"glass", "1"}, {"clay_ball", "1"}, {"brick", "2"},
                {"wheat", "1"}, {"wheat_seeds", "0.5"}, {"carrot", "1"}, {"potato", "1"}, {"baked_potato", "2"},
                {"poisonous_potato", "1"}, {"pumpkin", "2"}, {"melon_slice", "1"}, {"sugar_cane", "1"}, {"sugar", "1"},
                {"cactus", "1"}, {"green_dye", "1"}, {"cocoa_beans", "1"}, {"red_mushroom", "1"}, {"brown_mushroom", "1"},
                {"oak_log", "2"}, {"birch_log", "2"}, {"spruce_log", "2"}, {"jungle_log", "2"}, {"acacia_log", "2"},
                {"dark_oak_log", "2"}, {"rotten_flesh", "1"}, {"bone", "1"}, {"bone_meal", "1"}, {"string", "1"},
                {"spider_eye", "2"}, {"gunpowder", "2"}, {"ender_pearl", "10"}, {"blaze_rod", "5"}, {"blaze_powder", "3"},
                {"slime_ball", "3"}, {"leather", "2"}, {"feather", "1"}, {"ink_sac", "1"}, {"magma_cream", "3"},
                {"ghast_tear", "10"}, {"nether_wart", "2"}, {"netherrack", "0.5"}, {"end_stone", "1"},
                {"beef", "1"}, {"porkchop", "1"}, {"chicken", "1"}, {"mutton", "1"}, {"rabbit", "1"}, {"cod", "1"},
                {"salmon", "1"}, {"cooked_beef", "2"}, {"cooked_porkchop", "2"}, {"cooked_chicken", "2"},
                {"cooked_mutton", "2"}, {"cooked_rabbit", "2"}, {"cooked_cod", "2"}, {"cooked_salmon", "2"},
                {"prismarine_shard", "2"}, {"prismarine_crystals", "3"}, {"pufferfish", "2"}, {"rabbit_foot", "5"},
                {"rabbit_hide", "1"}, {"poppy", "1"}, {"dandelion", "1"}, {"hay_block", "9"}, {"ice", "1"},
                {"snow_block", "1"}, {"sponge", "5"}, {"mycelium", "2"}, {"bread", "2"}, {"cookie", "1"}
        };
        for (String[] e : p) m.put("minecraft:" + e[0], Double.parseDouble(e[1]));
        return m;
    }

    public static void load() {
        TABLE.clear();
        DERIVED.clear();
        Path f = CoinsCfg.dir().resolve("prices.json");
        try {
            Files.createDirectories(CoinsCfg.dir());
            if (!Files.exists(f)) {
                try (Writer w = Files.newBufferedWriter(f)) { CoinsCfg.GSON.toJson(defaults(), w); }
            }
            try (Reader r = Files.newBufferedReader(f)) {
                Map<String, Double> m = CoinsCfg.GSON.fromJson(r, new TypeToken<LinkedHashMap<String, Double>>() {}.getType());
                if (m != null) TABLE.putAll(m);
            }
        } catch (Exception e) {
            CoinsMod.LOGGER.error("Could not read prices.json", e);
            TABLE.putAll(defaults());
        }
        CoinsMod.LOGGER.info("Skyblock Coins: {} prices loaded", TABLE.size());
    }

    private static double vanilla(String key) {
        return TABLE.getOrDefault(key, CoinsCfg.C.default_price);
    }

    /** Enchanted item: a price in prices.json ("sb:enchanted_coal") or the cost of its crafting ingredients. */
    private static double enchanted(String id, int depth) {
        Double fixed = TABLE.get("sb:" + id);
        if (fixed != null) return fixed;
        Double cached = DERIVED.get(id);
        if (cached != null) return cached;
        SkyData.RecipeDef r = SkyData.RECIPES.get(id);
        if (r == null || depth > 6) return 0;
        double sum = 0;
        for (String row : r.pattern) {
            for (char ch : row.toCharArray()) {
                if (ch == ' ') continue;
                SkyData.Ing ing = r.key.get(String.valueOf(ch));
                if (ing == null || ing.items.isEmpty()) continue;
                String it = ing.items.get(0);
                double p = it.startsWith("sb:") ? enchanted(it.substring(3), depth + 1) : vanilla(it);
                sum += p * ing.count;
            }
        }
        double price = sum * CoinsCfg.C.enchanted_markup / Math.max(1, r.count);
        DERIVED.put(id, price);
        return price;
    }

    /** Coins for ONE item of this stack. */
    public static double priceOf(ItemStack st) {
        if (st.isEmpty()) return 0;
        String sb = SkyItems.sbId(st);
        if (sb != null) return enchanted(sb, 0);
        return vanilla(PlayerStats.key(st));
    }

    public static double valueOf(ItemStack st) {
        return priceOf(st) * st.getCount();
    }
}
