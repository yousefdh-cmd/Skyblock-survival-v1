package com.skyblocksurvival.coins;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

import java.util.List;

import static com.skyblocksurvival.coins.Coins.fmt;

/** /sell: put items in the top 5 rows, press the gold button. A normal chest screen, so no client mod is needed. */
public final class SellMenu extends ChestMenu {
    private static final int INPUT = 45;   // slots 0-44 take items
    private static final int BUTTON = 49;  // sell button

    private final Container box;

    public SellMenu(int id, Inventory inv) {
        this(id, inv, new SimpleContainer(54));
    }

    private SellMenu(int id, Inventory inv, Container box) {
        super(MenuType.GENERIC_9x6, id, inv, box, 6);
        this.box = box;
        ItemStack pane = new ItemStack(Items.BLACK_STAINED_GLASS_PANE);
        pane.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
        for (int i = INPUT; i < 54; i++) box.setItem(i, pane.copy());
        refreshButton();
    }

    private static Component plain(String s, ChatFormatting c) {
        return Component.literal(s).setStyle(Style.EMPTY.withColor(c).withItalic(false));
    }

    private double estimate() {
        double total = 0;
        for (int i = 0; i < INPUT; i++) total += Prices.valueOf(box.getItem(i));
        return total;
    }

    private void refreshButton() {
        ItemStack b = new ItemStack(Items.GOLD_INGOT);
        b.set(DataComponents.CUSTOM_NAME, plain("Sell Items", ChatFormatting.GREEN).copy().withStyle(ChatFormatting.BOLD));
        b.set(DataComponents.LORE, new ItemLore(List.of(
                plain("Click to sell everything above.", ChatFormatting.GRAY),
                plain("Items that cannot be sold come back to you.", ChatFormatting.GRAY),
                Component.empty(),
                plain("You will get: " + fmt(Math.round(estimate())) + " coins", ChatFormatting.GOLD))));
        box.setItem(BUTTON, b);
    }

    private void sell(ServerPlayer p) {
        double total = 0;
        for (int i = 0; i < INPUT; i++) {
            ItemStack st = box.getItem(i);
            if (st.isEmpty()) continue;
            double v = Prices.valueOf(st);
            if (v <= 0) continue;
            total += v;
            box.setItem(i, ItemStack.EMPTY);
        }
        long coins = Math.round(total);
        if (coins > 0) {
            Purse.add(p.getUUID(), coins);
            p.sendSystemMessage(plain("You sold items for " + fmt(coins) + " coins. Purse: "
                    + fmt(Purse.get(p.getUUID())), ChatFormatting.GOLD));
        } else {
            p.sendSystemMessage(plain("Nothing here can be sold.", ChatFormatting.RED));
        }
    }

    public void clicked(int slotId, int button, ClickType type, Player player) {
        if (slotId >= INPUT && slotId < 54) { // the bottom row never moves
            if (slotId == BUTTON && player instanceof ServerPlayer sp) {
                sell(sp);
                refreshButton();
            }
            return;
        }
        super.clicked(slotId, button, type, player);
        refreshButton();
    }

    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = this.slots.get(index);
        if (!slot.hasItem() || (index >= INPUT && index < 54)) return ItemStack.EMPTY;
        ItemStack stack = slot.getItem();
        ItemStack copy = stack.copy();
        if (index < INPUT) {
            if (!this.moveItemStackTo(stack, 54, this.slots.size(), true)) return ItemStack.EMPTY;
        } else if (!this.moveItemStackTo(stack, 0, INPUT, false)) {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
        else slot.setChanged();
        refreshButton();
        return copy;
    }

    public boolean canDragTo(Slot slot) {
        return !(slot.container == box && slot.getContainerSlot() >= INPUT);
    }

    public void removed(Player player) {
        for (int i = 0; i < INPUT; i++) { // give back whatever was not sold
            ItemStack st = box.removeItemNoUpdate(i);
            if (!st.isEmpty()) player.getInventory().placeItemBackInInventory(st);
        }
        super.removed(player);
    }
}
