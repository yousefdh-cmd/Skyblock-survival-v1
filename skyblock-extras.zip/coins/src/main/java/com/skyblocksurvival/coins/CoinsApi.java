package com.skyblocksurvival.coins;

import net.minecraft.world.item.ItemStack;

import java.util.UUID;

/** For other mods (for example the minions add-on). */
public final class CoinsApi {
    private CoinsApi() {}

    public static long balance(UUID player) { return Purse.get(player); }
    public static void add(UUID player, long coins) { Purse.add(player, coins); }
    public static boolean take(UUID player, long coins) { return Purse.take(player, coins); }
    /** Coins one item of this stack sells for (0 = cannot be sold). */
    public static double priceOf(ItemStack st) { return Prices.priceOf(st); }
}
