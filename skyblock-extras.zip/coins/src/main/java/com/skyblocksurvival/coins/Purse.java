package com.skyblocksurvival.coins;

import com.google.gson.reflect.TypeToken;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Every player's coins, saved in the world folder (skyblockcoins.json). */
public final class Purse {
    private static final Map<UUID, Long> MAP = new HashMap<>();
    private static Path file;
    private static boolean dirty;

    public static synchronized void load(MinecraftServer server) {
        MAP.clear();
        dirty = false;
        file = server.getWorldPath(LevelResource.ROOT).resolve("skyblockcoins.json");
        try {
            if (Files.exists(file)) {
                try (Reader r = Files.newBufferedReader(file)) {
                    Map<String, Long> m = CoinsCfg.GSON.fromJson(r, new TypeToken<HashMap<String, Long>>() {}.getType());
                    if (m != null) {
                        for (Map.Entry<String, Long> en : m.entrySet()) MAP.put(UUID.fromString(en.getKey()), en.getValue());
                    }
                }
            }
        } catch (Exception e) {
            CoinsMod.LOGGER.error("Could not read skyblockcoins.json", e);
        }
    }

    public static synchronized void save() {
        if (file == null) return;
        try {
            Map<String, Long> out = new HashMap<>();
            for (Map.Entry<UUID, Long> en : MAP.entrySet()) out.put(en.getKey().toString(), en.getValue());
            try (Writer w = Files.newBufferedWriter(file)) { CoinsCfg.GSON.toJson(out, w); }
            dirty = false;
        } catch (Exception e) {
            CoinsMod.LOGGER.error("Could not save skyblockcoins.json", e);
        }
    }

    public static synchronized void saveIfDirty() {
        if (dirty) save();
    }

    public static synchronized void unload() {
        save();
        MAP.clear();
        file = null;
    }

    public static synchronized long get(UUID id) {
        return MAP.getOrDefault(id, 0L);
    }

    public static synchronized void set(UUID id, long amount) {
        MAP.put(id, Math.max(0L, amount));
        dirty = true;
    }

    public static synchronized void add(UUID id, long amount) {
        set(id, get(id) + amount);
    }

    /** Takes the coins only if the player has enough. */
    public static synchronized boolean take(UUID id, long amount) {
        long have = get(id);
        if (have < amount) return false;
        set(id, have - amount);
        return true;
    }
}
