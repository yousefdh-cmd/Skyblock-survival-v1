package com.skyblocksurvival.coins;

import com.mojang.logging.LogUtils;
import net.neoforged.fml.common.Mod;
import org.slf4j.Logger;

@Mod(CoinsMod.MODID)
public class CoinsMod {
    public static final String MODID = "skyblockcoins";
    public static final Logger LOGGER = LogUtils.getLogger();

    public CoinsMod() {
        CoinsCfg.load();
        Prices.load();
    }
}
