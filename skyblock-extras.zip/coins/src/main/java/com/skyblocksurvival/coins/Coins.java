package com.skyblocksurvival.coins;

import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.skyblocksurvival.PlayerStats;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.Locale;

/** Events and commands of the coins mod. */
@EventBusSubscriber(modid = CoinsMod.MODID)
public final class Coins {

    public static String fmt(long v) {
        return String.format(Locale.US, "%,d", v);
    }

    private static Component gold(String s) {
        return Component.literal(s).setStyle(Style.EMPTY.withColor(ChatFormatting.GOLD).withItalic(false));
    }

    // ------------------------------------------------------------------ world lifecycle
    @SubscribeEvent
    public static void onStarting(ServerStartingEvent e) {
        Purse.load(e.getServer());
    }

    @SubscribeEvent
    public static void onStopping(ServerStoppingEvent e) {
        Purse.unload();
    }

    @SubscribeEvent
    public static void onTick(ServerTickEvent.Post e) {
        if (e.getServer().getTickCount() % 1200 == 0) Purse.saveIfDirty(); // every minute
    }

    // ------------------------------------------------------------------ coins from mobs
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        LivingEntity v = e.getEntity();
        if (v.level().isClientSide() || !(e.getSource().getEntity() instanceof ServerPlayer p)) return;
        CompoundTag t = v.getPersistentData();
        if (!t.contains("sb_lvl")) return; // only mobs that the core mod gave a level to

        CoinsCfg.Cfg c = CoinsCfg.C;
        double mult = (v instanceof Enemy) ? 1.0 : c.passive_multiplier;
        if (mult <= 0) return;
        double coins = c.mob_coins_base * (1 + (t.getInt("sb_lvl") - 1) * c.mob_coins_per_level) * mult;
        coins *= 1 + (p.getRandom().nextDouble() * 2 - 1) * c.random_spread;
        coins *= 1 + PlayerStats.of(p).magicFind / 100.0;
        long n = Math.max(1, Math.round(coins));
        Purse.add(p.getUUID(), n);
        if (c.show_messages) p.sendSystemMessage(gold("+" + fmt(n) + " coins"));
    }

    // ------------------------------------------------------------------ commands
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("purse").executes(c -> {
            ServerPlayer p = c.getSource().getPlayerOrException();
            c.getSource().sendSuccess(() -> gold("Purse: " + fmt(Purse.get(p.getUUID())) + " coins"), false);
            return 1;
        }));

        e.getDispatcher().register(Commands.literal("sell").executes(c -> {
            ServerPlayer p = c.getSource().getPlayerOrException();
            p.openMenu(new SimpleMenuProvider((id, inv, pl) -> new SellMenu(id, inv), Component.literal("Sell Items")));
            return 1;
        }));

        e.getDispatcher().register(Commands.literal("pay")
                .then(Commands.argument("player", EntityArgument.player())
                        .then(Commands.argument("amount", LongArgumentType.longArg(1))
                                .executes(c -> pay(c.getSource(), EntityArgument.getPlayer(c, "player"),
                                        LongArgumentType.getLong(c, "amount"))))));

        e.getDispatcher().register(Commands.literal("coins")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("give").then(Commands.argument("player", EntityArgument.player())
                        .then(Commands.argument("amount", LongArgumentType.longArg(1)).executes(c -> {
                            ServerPlayer t = EntityArgument.getPlayer(c, "player");
                            Purse.add(t.getUUID(), LongArgumentType.getLong(c, "amount"));
                            return done(c.getSource(), t);
                        }))))
                .then(Commands.literal("take").then(Commands.argument("player", EntityArgument.player())
                        .then(Commands.argument("amount", LongArgumentType.longArg(1)).executes(c -> {
                            ServerPlayer t = EntityArgument.getPlayer(c, "player");
                            Purse.set(t.getUUID(), Purse.get(t.getUUID()) - LongArgumentType.getLong(c, "amount"));
                            return done(c.getSource(), t);
                        }))))
                .then(Commands.literal("set").then(Commands.argument("player", EntityArgument.player())
                        .then(Commands.argument("amount", LongArgumentType.longArg(0)).executes(c -> {
                            ServerPlayer t = EntityArgument.getPlayer(c, "player");
                            Purse.set(t.getUUID(), LongArgumentType.getLong(c, "amount"));
                            return done(c.getSource(), t);
                        })))));

        e.getDispatcher().register(Commands.literal("coinsreload")
                .requires(s -> s.hasPermission(2))
                .executes(c -> {
                    CoinsCfg.load();
                    Prices.load();
                    c.getSource().sendSuccess(() -> gold("Skyblock Coins: config and prices reloaded"), true);
                    return 1;
                }));
    }

    private static int done(CommandSourceStack src, ServerPlayer target) {
        src.sendSuccess(() -> gold(target.getGameProfile().getName() + " now has "
                + fmt(Purse.get(target.getUUID())) + " coins"), true);
        return 1;
    }

    private static int pay(CommandSourceStack src, ServerPlayer to, long amount) throws CommandSyntaxException {
        ServerPlayer from = src.getPlayerOrException();
        if (from.getUUID().equals(to.getUUID())) {
            src.sendFailure(Component.literal("You cannot pay yourself."));
            return 0;
        }
        if (!Purse.take(from.getUUID(), amount)) {
            src.sendFailure(Component.literal("You only have " + fmt(Purse.get(from.getUUID())) + " coins."));
            return 0;
        }
        Purse.add(to.getUUID(), amount);
        src.sendSuccess(() -> gold("You paid " + fmt(amount) + " coins to " + to.getGameProfile().getName()), false);
        to.sendSystemMessage(gold(from.getGameProfile().getName() + " paid you " + fmt(amount) + " coins"));
        return 1;
    }
}
