package com.skyblocksurvival.coins;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.neoforged.fml.loading.FMLPaths;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** config/skyblockcoins/config.json (created on first run). */
public final class CoinsCfg {
    public static class Cfg {
        public double mob_coins_base = 2;          // coins from a level 1 hostile mob
        public double mob_coins_per_level = 0.25;  // coins x (1 + (level-1) * this): about 500 at level 999
        public double passive_multiplier = 0;      // animals and villagers (0 = no coins)
        public double random_spread = 0.2;         // +-20% random
        public boolean show_messages = true;       // "+12 coins" in chat
        public double default_price = 0;           // price of an item that is not in prices.json (0 = cannot be sold)
        public double enchanted_markup = 1.0;      // Enchanted item price = its ingredients' price x this
    }

    public static Cfg C = new Cfg();
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static Path dir() {
        return FMLPaths.CONFIGDIR.get().resolve("skyblockcoins");
    }

    public static void load() {
        try {
            Files.createDirectories(dir());
            Path f = dir().resolve("config.json");
            if (!Files.exists(f)) {
                try (Writer w = Files.newBufferedWriter(f)) { GSON.toJson(new Cfg(), w); }
            }
            try (Reader r = Files.newBufferedReader(f)) {
                Cfg c = GSON.fromJson(r, Cfg.class);
                C = c == null ? new Cfg() : c;
            }
        } catch (Exception e) {
            CoinsMod.LOGGER.error("Could not read config.json", e);
            C = new Cfg();
        }
    }
}
