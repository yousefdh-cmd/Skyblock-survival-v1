package com.skyblocksurvival.enchants;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.neoforged.fml.loading.FMLPaths;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** config/skyblockenchants/config.json (created on first run). Chances are fractions: 0.03 = 3%. */
public final class EnchantCfg {
    public static class Cfg {
        public double boss_chance = 0.03;           // Warden, Wither, Ender Dragon, Elder Guardian
        public List<String> boss_ids = new ArrayList<>(List.of("warden", "wither", "ender_dragon", "elder_guardian"));
        public double level500_chance = 0.0002;     // any mob at level 501
        public double level999_chance = 0.003;      // any mob at level 999 (in between: grows with the level)
        public double[] ultimate_level_weights = {60, 25, 10, 4, 1}; // weight of book level I, II, III, IV, V
        public int combo_max_stacks = 5;
        public int combo_window_ticks = 120;        // 6 seconds
        public int swarm_max_mobs = 10;
        public double swarm_radius = 8;
    }

    public static Cfg C = new Cfg();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static void load() {
        Path dir = FMLPaths.CONFIGDIR.get().resolve("skyblockenchants");
        try {
            Files.createDirectories(dir);
            Path f = dir.resolve("config.json");
            if (!Files.exists(f)) {
                try (Writer w = Files.newBufferedWriter(f)) { GSON.toJson(new Cfg(), w); }
            }
            try (Reader r = Files.newBufferedReader(f)) {
                Cfg c = GSON.fromJson(r, Cfg.class);
                C = c == null ? new Cfg() : c;
            }
        } catch (Exception e) {
            EnchantMod.LOGGER.error("Could not read config.json", e);
            C = new Cfg();
        }
    }
}
