package com.skyblocksurvival.enchants;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/** Names, max levels, per-level values and descriptions (bundled enchants.json). */
public final class EnchDefs {
    public static class Def {
        public String name = "";
        public int max = 1;
        public boolean ultimate = false;
        public double[] vals = new double[0];
        public double[] vals2 = new double[0];
        public String desc = "";
    }

    public static final Map<String, Def> DEFS = new LinkedHashMap<>();

    public static void load() {
        try (Reader r = new InputStreamReader(EnchDefs.class.getResourceAsStream("/enchants.json"), StandardCharsets.UTF_8)) {
            Map<String, Def> m = new Gson().fromJson(r, new TypeToken<LinkedHashMap<String, Def>>() {}.getType());
            if (m != null) DEFS.putAll(m);
        } catch (Exception e) {
            EnchantMod.LOGGER.error("Could not read enchants.json", e);
        }
    }

    private static double at(double[] a, int lvl) {
        if (a.length == 0) return 0;
        return a[Math.max(0, Math.min(a.length, lvl) - 1)];
    }

    public static double val(String id, int lvl) {
        Def d = DEFS.get(id);
        return d == null ? 0 : at(d.vals, lvl);
    }

    public static double val2(String id, int lvl) {
        Def d = DEFS.get(id);
        return d == null ? 0 : at(d.vals2, lvl);
    }
}
