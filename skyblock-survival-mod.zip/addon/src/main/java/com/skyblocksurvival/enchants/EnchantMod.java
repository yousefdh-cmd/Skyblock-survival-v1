package com.skyblocksurvival.enchants;

import com.mojang.logging.LogUtils;
import com.skyblocksurvival.SkyApi;
import net.neoforged.fml.common.Mod;
import org.slf4j.Logger;

@Mod(EnchantMod.MODID)
public class EnchantMod {
    public static final String MODID = "skyblockenchants";
    public static final Logger LOGGER = LogUtils.getLogger();

    public EnchantMod() {
        EnchDefs.load();
        EnchantCfg.load();
        SkyApi.ENCHANT_LINES = EnchantUtil::lines; // colored enchantment lines on weapons and armor
        LOGGER.info("Skyblock Enchantments loaded {} enchantments", EnchDefs.DEFS.size());
    }
}
