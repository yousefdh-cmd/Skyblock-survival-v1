package com.skyblocksurvival.enchants;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import java.util.Optional;

/** /sbenchant <name> <level>: enchants the item in your hand, or gives an enchanted book if you hold a book or nothing. */
@EventBusSubscriber(modid = EnchantMod.MODID)
public final class EnchantCommands {

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("sbenchant")
                .requires(s -> s.hasPermission(2))
                .then(Commands.argument("id", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(EnchDefs.DEFS.keySet(), b))
                        .then(Commands.argument("level", IntegerArgumentType.integer(1, 10))
                                .executes(c -> run(c.getSource(), StringArgumentType.getString(c, "id"),
                                        IntegerArgumentType.getInteger(c, "level"))))));
    }

    private static int run(CommandSourceStack src, String id, int level) throws CommandSyntaxException {
        EnchDefs.Def d = EnchDefs.DEFS.get(id);
        if (d == null) {
            src.sendFailure(Component.literal("Unknown enchantment: " + id));
            return 0;
        }
        ServerPlayer p = src.getPlayerOrException();
        int lvl = Math.min(level, d.max);
        ItemStack hand = p.getMainHandItem();

        if (hand.isEmpty() || hand.is(Items.BOOK) || hand.is(Items.ENCHANTED_BOOK)) {
            ItemStack book = EnchantUtil.book(p.level(), id, lvl);
            if (book.isEmpty()) {
                src.sendFailure(Component.literal("Enchantment not loaded: " + id));
                return 0;
            }
            if (!p.getInventory().add(book)) p.drop(book, false);
            return 1;
        }

        Optional<Holder.Reference<Enchantment>> h = EnchantUtil.holder(p.level(), id);
        if (h.isEmpty()) {
            src.sendFailure(Component.literal("Enchantment not loaded: " + id));
            return 0;
        }
        EnchantmentHelper.updateEnchantments(hand, m -> m.set(h.get(), lvl));
        return 1;
    }
}
