package com.skyblocksurvival.enchants;

import com.skyblocksurvival.PlayerStats;
import com.skyblocksurvival.SkyHitEvent;
import com.skyblocksurvival.SkyHurtEvent;
import com.skyblocksurvival.SkyStatsEvent;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.entity.living.LivingExperienceDropEvent;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** All enchantment effects. They plug into the core mod through its stats / hit / hurt events. */
@EventBusSubscriber(modid = EnchantMod.MODID)
public final class EnchantHooks {
    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private static String typeKey(LivingEntity v) {
        return BuiltInRegistries.ENTITY_TYPE.getKey(v.getType()).getPath();
    }

    private static void heal(Player p, double percentOfMax) {
        p.heal((float) (p.getMaxHealth() * percentOfMax / 100.0));
    }

    // ------------------------------------------------------------------ stats
    @SubscribeEvent
    public static void onStats(SkyStatsEvent e) {
        Player p = e.player;
        PlayerStats s = e.stats;

        for (Map.Entry<String, Integer> en : EnchantUtil.read(p.getMainHandItem()).entrySet()) {
            double v = EnchDefs.val(en.getKey(), en.getValue());
            switch (en.getKey()) {
                case "critical" -> s.critDamage += v;
                case "overload" -> {
                    s.critChance += v;
                    s.critDamage += EnchDefs.val2("overload", en.getValue());
                }
                case "vicious" -> s.ferocity += v;
                default -> { }
            }
        }

        int lastStand = 0;
        for (EquipmentSlot slot : ARMOR) {
            for (Map.Entry<String, Integer> en : EnchantUtil.read(p.getItemBySlot(slot)).entrySet()) {
                double v = EnchDefs.val(en.getKey(), en.getValue());
                switch (en.getKey()) {
                    case "growth" -> s.health += v;
                    case "protection" -> s.defense += v;
                    case "true_protection" -> s.trueDefense += v;
                    case "big_brain", "smarty_pants" -> s.intelligence += v;
                    case "rejuvenate", "respite" -> s.healthRegen += v;
                    case "last_stand" -> lastStand += en.getValue();
                    default -> { }
                }
            }
        }
        if (lastStand > 0 && p.getHealth() < p.getMaxHealth() * 0.4) {
            s.defense *= 1 + 0.05 * lastStand;
        }
    }

    // ------------------------------------------------------------------ armor vs. the kind of damage
    @SubscribeEvent
    public static void onHurt(SkyHurtEvent e) {
        for (EquipmentSlot slot : ARMOR) {
            for (Map.Entry<String, Integer> en : EnchantUtil.read(e.player.getItemBySlot(slot)).entrySet()) {
                double v = EnchDefs.val(en.getKey(), en.getValue());
                switch (en.getKey()) {
                    case "blast_protection" -> { if (e.source.is(DamageTypeTags.IS_EXPLOSION)) e.defense += v; }
                    case "projectile_protection" -> { if (e.source.is(DamageTypeTags.IS_PROJECTILE)) e.defense += v; }
                    case "fire_protection" -> { if (e.source.is(DamageTypeTags.IS_FIRE)) e.trueDefense += v; }
                    default -> { }
                }
            }
        }
    }

    // ------------------------------------------------------------------ weapon vs. the mob
    @SubscribeEvent
    public static void onHit(SkyHitEvent e) {
        Player p = e.attacker;
        LivingEntity v = e.victim;
        CompoundTag vt = v.getPersistentData();
        CompoundTag pt = p.getPersistentData();
        long now = p.level().getGameTime();
        int hits = vt.getInt("sbe_hits");
        vt.putInt("sbe_hits", hits + 1);

        Map<String, Integer> w = EnchantUtil.read(p.getMainHandItem());
        if (w.isEmpty()) return;
        if (w.containsKey("one_for_all")) { // +500% damage, every other enchantment is ignored
            e.damage *= 1 + EnchDefs.val("one_for_all", 1) / 100.0;
            return;
        }

        boolean sb = vt.contains("sb_max");
        double frac = Math.max(0, Math.min(1, v.getHealth() / v.getMaxHealth()));
        String type = typeKey(v);
        double bonus = 0;     // percent, additive like in Skyblock
        double thunder = 0;   // flat extra damage

        for (Map.Entry<String, Integer> en : w.entrySet()) {
            String id = en.getKey();
            int lvl = en.getValue();
            double val = EnchDefs.val(id, lvl);
            switch (id) {
                case "sharpness" -> { if (e.melee) bonus += val; }
                case "power" -> { if (!e.melee) bonus += val; }
                case "smite" -> { if (v.getType().is(EntityTypeTags.UNDEAD)) bonus += val; }
                case "bane_of_arthropods" -> { if (v.getType().is(EntityTypeTags.ARTHROPOD)) bonus += val; }
                case "ender_slayer" -> {
                    if (type.equals("enderman") || type.equals("endermite") || type.equals("ender_dragon")) bonus += val;
                }
                case "cubism" -> {
                    if (type.equals("creeper") || type.equals("slime") || type.equals("magma_cube")) bonus += val;
                }
                case "impaling" -> { if (v.getType().is(EntityTypeTags.AQUATIC)) bonus += val; }
                case "dragon_hunter" -> {
                    if (type.equals("ender_dragon") || type.equals("phantom") || type.equals("ghast") || type.equals("vex")) bonus += val;
                }
                case "execute" -> bonus += val * (1 - frac) * 100.0;
                case "prosecute" -> bonus += val * frac * 100.0;
                case "first_strike" -> { if (hits == 0) bonus += val; }
                case "triple_strike" -> { if (hits < 3) bonus += val; }
                case "giant_killer" -> {
                    double vHp = sb ? frac * vt.getDouble("sb_max") : v.getHealth();
                    double extra = Math.max(0, (vHp - e.stats.health) / Math.max(1, e.stats.health) * 100.0);
                    bonus += Math.min(EnchDefs.val2(id, lvl), val * extra);
                }
                case "titan_killer" -> {
                    double def = vt.getDouble("sb_def");
                    bonus += Math.min(EnchDefs.val2(id, lvl), val * def / 100.0);
                }
                case "snipe" -> { if (!e.melee) bonus += val * (p.distanceTo(v) / 10.0); }
                case "venomous" -> {
                    int st = vt.getInt("sbe_ven");
                    if (now - vt.getLong("sbe_ven_t") > 100) st = 0;
                    st = Math.min(40, st + 1);
                    vt.putInt("sbe_ven", st);
                    vt.putLong("sbe_ven_t", now);
                    bonus += val * st;
                }
                case "combo" -> {
                    if (now - pt.getLong("sbe_combo_t") <= EnchantCfg.C.combo_window_ticks) {
                        bonus += val * pt.getInt("sbe_combo");
                    }
                }
                case "swarm" -> {
                    AABB box = v.getBoundingBox().inflate(EnchantCfg.C.swarm_radius);
                    List<Mob> near = v.level().getEntitiesOfClass(Mob.class, box, m -> m != v && m instanceof Enemy && m.isAlive());
                    bonus += val * Math.min(EnchantCfg.C.swarm_max_mobs, near.size());
                }
                case "thunderbolt", "thunderlord" -> {
                    int c = pt.getInt("sbe_thunder") + 1;
                    pt.putInt("sbe_thunder", c);
                    if (c % 3 == 0) thunder += e.stats.strength * val / 100.0;
                }
                case "life_steal" -> heal(p, val);
                case "drain" -> heal(p, val * Math.min(e.stats.critDamage, 1000) / 100.0);
                case "mana_steal" -> {
                    double max = e.stats.intelligence;
                    double mana = pt.contains("sb_mana") ? pt.getDouble("sb_mana") : max;
                    pt.putDouble("sb_mana", Math.min(max, mana + max * val / 100.0));
                }
                case "lethality" -> {
                    int st = vt.getInt("sbe_leth");
                    if (now - vt.getLong("sbe_leth_t") > 80) st = 0;
                    st = Math.min(4, st + 1);
                    vt.putInt("sbe_leth", st);
                    vt.putLong("sbe_leth_t", now);
                    e.defenseMultiplier *= Math.max(0, 1 - st * val / 100.0);
                }
                default -> { }
            }
        }
        e.damage = e.damage * (1 + bonus / 100.0) + thunder;
    }

    // ------------------------------------------------------------------ kills
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!(e.getSource().getEntity() instanceof Player p) || p.level().isClientSide()) return;
        Map<String, Integer> w = EnchantUtil.read(p.getMainHandItem());
        long now = p.level().getGameTime();
        CompoundTag pt = p.getPersistentData();
        if (w.containsKey("combo")) {
            int st = pt.getInt("sbe_combo");
            if (now - pt.getLong("sbe_combo_t") > EnchantCfg.C.combo_window_ticks) st = 0;
            pt.putInt("sbe_combo", Math.min(EnchantCfg.C.combo_max_stacks, st + 1));
            pt.putLong("sbe_combo_t", now);
        }
        Integer vamp = w.get("vampirism");
        if (vamp != null) {
            p.heal((float) ((p.getMaxHealth() - p.getHealth()) * EnchDefs.val("vampirism", vamp) / 100.0));
        }
    }

    @SubscribeEvent
    public static void onXp(LivingExperienceDropEvent e) {
        Player p = e.getAttackingPlayer();
        if (p == null) return;
        Integer lvl = EnchantUtil.read(p.getMainHandItem()).get("experience");
        if (lvl != null && p.getRandom().nextDouble() * 100.0 < EnchDefs.val("experience", lvl)) {
            e.setDroppedExperience(e.getDroppedExperience() * 2);
        }
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Integer l = EnchantUtil.read(p.getItemBySlot(EquipmentSlot.FEET)).get("feather_falling");
        if (l == null) return;
        e.setDistance(Math.max(0f, e.getDistance() - (float) EnchDefs.val2("feather_falling", l)));
        e.setDamageMultiplier(e.getDamageMultiplier() * (float) (1 - EnchDefs.val("feather_falling", l) / 100.0));
    }

    // ------------------------------------------------------------------ drops: Looting + Ultimate books
    @SubscribeEvent
    public static void onDrops(LivingDropsEvent e) {
        LivingEntity v = e.getEntity();
        if (v.level().isClientSide() || !(e.getSource().getEntity() instanceof Player p)) return;
        CompoundTag vt = v.getPersistentData();
        if (!vt.contains("sb_lvl")) return;

        List<ItemEntity> extra = new ArrayList<>();
        Integer loot = EnchantUtil.read(p.getMainHandItem()).get("looting");
        if (loot != null) {
            double chance = EnchDefs.val("looting", loot) / 100.0;
            for (ItemEntity ie : e.getDrops()) {
                ItemStack st = ie.getItem();
                if (st.getMaxStackSize() > 1 && v.getRandom().nextDouble() < chance) {
                    extra.add(new ItemEntity(v.level(), ie.getX(), ie.getY(), ie.getZ(), st.copyWithCount(1)));
                }
            }
        }

        // Ultimate enchantment book
        EnchantCfg.Cfg c = EnchantCfg.C;
        int mobLevel = vt.getInt("sb_lvl");
        double chance = 0;
        if (c.boss_ids.contains(typeKey(v))) {
            chance = c.boss_chance;
        } else if (mobLevel > 500) {
            chance = c.level500_chance + (c.level999_chance - c.level500_chance) * (mobLevel - 500) / 499.0;
        }
        chance *= 1 + PlayerStats.of(p).magicFind / 100.0;
        if (chance > 0 && v.getRandom().nextDouble() < chance) {
            List<String> ults = new ArrayList<>();
            for (Map.Entry<String, EnchDefs.Def> en : EnchDefs.DEFS.entrySet()) {
                if (en.getValue().ultimate) ults.add(en.getKey());
            }
            if (!ults.isEmpty()) {
                String id = ults.get(v.getRandom().nextInt(ults.size()));
                int max = EnchDefs.DEFS.get(id).max;
                double total = 0;
                for (int i = 0; i < max && i < c.ultimate_level_weights.length; i++) total += c.ultimate_level_weights[i];
                double x = v.getRandom().nextDouble() * total;
                int lvl = 1;
                for (int i = 0; i < max && i < c.ultimate_level_weights.length; i++) {
                    x -= c.ultimate_level_weights[i];
                    if (x < 0) { lvl = i + 1; break; }
                }
                ItemStack book = EnchantUtil.book(v.level(), id, lvl);
                if (!book.isEmpty()) {
                    extra.add(new ItemEntity(v.level(), v.getX(), v.getY(), v.getZ(), book));
                    p.sendSystemMessage(Component.literal("ULTIMATE ENCHANTMENT BOOK DROP! ")
                            .withStyle(ChatFormatting.LIGHT_PURPLE).withStyle(ChatFormatting.BOLD)
                            .append(EnchantUtil.line(id, lvl)));
                }
            }
        }
        e.getDrops().addAll(extra);
    }
}
