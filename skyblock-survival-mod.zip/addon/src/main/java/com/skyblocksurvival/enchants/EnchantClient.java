package com.skyblocksurvival.enchants;

import com.skyblocksurvival.SkyData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Enchanted books with our enchantments look like Skyblock books: colored name, descriptions, rarity. */
@EventBusSubscriber(modid = EnchantMod.MODID, value = Dist.CLIENT)
public final class EnchantClient {

    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent e) {
        ItemStack st = e.getItemStack();
        if (!st.is(Items.ENCHANTED_BOOK)) return;
        List<Component> tt = e.getToolTip();
        if (tt.isEmpty()) return;

        Map<String, Integer> ours = new LinkedHashMap<>();
        EnchantUtil.collect(st.getOrDefault(DataComponents.STORED_ENCHANTMENTS, ItemEnchantments.EMPTY), ours);
        if (ours.isEmpty()) return; // ordinary vanilla books stay as they are

        boolean ultimate = false;
        int maxLevel = 1;
        for (Map.Entry<String, Integer> en : ours.entrySet()) {
            ultimate |= EnchDefs.DEFS.get(en.getKey()).ultimate;
            maxLevel = Math.max(maxLevel, en.getValue());
        }
        String rarity = EnchantUtil.rarityOf(maxLevel, ultimate);
        ChatFormatting color = SkyData.rarityColor(rarity);

        List<Component> out = new ArrayList<>();
        out.add(tt.get(0).copy().withStyle(color));
        for (Map.Entry<String, Integer> en : ours.entrySet()) {
            out.add(EnchantUtil.line(en.getKey(), en.getValue()));
            out.addAll(EnchantUtil.description(en.getKey(), en.getValue()));
        }
        out.add(Component.empty());
        out.add(Component.literal(rarity.toUpperCase(Locale.ROOT)).withStyle(color).withStyle(ChatFormatting.BOLD));

        tt.clear();
        tt.addAll(out);
    }
}
