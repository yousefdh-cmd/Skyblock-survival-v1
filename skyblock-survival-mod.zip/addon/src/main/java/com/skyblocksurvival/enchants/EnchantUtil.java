package com.skyblocksurvival.enchants;

import com.skyblocksurvival.SkyData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class EnchantUtil {
    public static final String NS = EnchantMod.MODID;

    /** Our enchantments on this stack: id -> level. */
    public static Map<String, Integer> read(ItemStack st) {
        Map<String, Integer> m = new LinkedHashMap<>();
        if (st.isEmpty()) return m;
        collect(st.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY), m);
        return m;
    }

    public static void collect(ItemEnchantments ench, Map<String, Integer> out) {
        for (var en : ench.entrySet()) {
            int lvl = en.getIntValue();
            en.getKey().unwrapKey().ifPresent(k -> {
                if (k.location().getNamespace().equals(NS) && EnchDefs.DEFS.containsKey(k.location().getPath())) {
                    out.put(k.location().getPath(), lvl);
                }
            });
        }
    }

    // ---- rarity by level: 1-4 COMMON, 5 UNCOMMON, 6 RARE, 7 EPIC, 8+ LEGENDARY; Ultimate = MYTHIC
    public static String rarityOf(int lvl, boolean ultimate) {
        if (ultimate) return "MYTHIC";
        if (lvl <= 4) return "COMMON";
        if (lvl == 5) return "UNCOMMON";
        if (lvl == 6) return "RARE";
        if (lvl == 7) return "EPIC";
        return "LEGENDARY";
    }

    public static String fmt(double v) {
        return v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    /** "Critical V" in the color of its rarity (Ultimate: bold light purple). */
    public static Component line(String id, int lvl) {
        EnchDefs.Def d = EnchDefs.DEFS.get(id);
        ChatFormatting c = SkyData.rarityColor(rarityOf(lvl, d.ultimate));
        MutableComponent m = Component.literal(d.name + " ").append(Component.translatable("enchantment.level." + lvl));
        m.setStyle(Style.EMPTY.withColor(c).withItalic(false).withBold(d.ultimate));
        return m;
    }

    /** The description of one enchantment at one level, as gray lines. */
    public static List<Component> description(String id, int lvl) {
        EnchDefs.Def d = EnchDefs.DEFS.get(id);
        String text = d.desc.replace("{v}", fmt(EnchDefs.val(id, lvl))).replace("{w}", fmt(EnchDefs.val2(id, lvl)));
        List<Component> out = new ArrayList<>();
        out.add(Component.literal(text).setStyle(Style.EMPTY.withColor(ChatFormatting.GRAY).withItalic(false)));
        return out;
    }

    /** Enchantment lines for weapons and armor (used by the core mod's tooltip). */
    public static List<Component> lines(ItemStack st) {
        List<Component> ult = new ArrayList<>();
        List<Component> rest = new ArrayList<>();
        ItemEnchantments ench = st.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);
        for (var en : ench.entrySet()) {
            Holder<Enchantment> h = en.getKey();
            int lvl = en.getIntValue();
            Optional<net.minecraft.resources.ResourceKey<Enchantment>> key = h.unwrapKey();
            if (key.isPresent() && key.get().location().getNamespace().equals(NS)
                    && EnchDefs.DEFS.containsKey(key.get().location().getPath())) {
                String id = key.get().location().getPath();
                (EnchDefs.DEFS.get(id).ultimate ? ult : rest).add(line(id, lvl));
            } else {
                MutableComponent m = h.value().description().copy().append(" ")
                        .append(Component.translatable("enchantment.level." + lvl));
                m.setStyle(Style.EMPTY.withColor(ChatFormatting.BLUE).withItalic(false));
                rest.add(m);
            }
        }
        ult.addAll(rest);
        return ult;
    }

    public static Optional<Holder.Reference<Enchantment>> holder(Level level, String id) {
        Registry<Enchantment> reg = level.registryAccess().registryOrThrow(Registries.ENCHANTMENT);
        return reg.getHolder(ResourceLocation.fromNamespaceAndPath(NS, id));
    }

    /** An enchanted book holding one of our enchantments. */
    public static ItemStack book(Level level, String id, int lvl) {
        Optional<Holder.Reference<Enchantment>> h = holder(level, id);
        if (h.isEmpty()) return ItemStack.EMPTY;
        ItemStack st = new ItemStack(Items.ENCHANTED_BOOK);
        ItemEnchantments.Mutable m = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);
        m.set(h.get(), lvl);
        st.set(DataComponents.STORED_ENCHANTMENTS, m.toImmutable());
        return st;
    }
}
