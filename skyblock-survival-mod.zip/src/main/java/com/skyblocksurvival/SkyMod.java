package com.skyblocksurvival;

import com.mojang.logging.LogUtils;
import net.neoforged.fml.common.Mod;
import org.slf4j.Logger;

@Mod(SkyMod.MODID)
public class SkyMod {
    public static final String MODID = "skyblocksurvival";
    public static final Logger LOGGER = LogUtils.getLogger();

    public SkyMod() {
        SkyData.load();
    }
}
