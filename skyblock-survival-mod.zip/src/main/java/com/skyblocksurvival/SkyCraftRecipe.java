package com.skyblocksurvival;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

/** One recipe object that answers for every recipe in recipes.json. */
public class SkyCraftRecipe implements CraftingRecipe {

    public boolean matches(CraftingInput input, Level level) {
        return SkyRecipes.find(input) != null;
    }

    public ItemStack assemble(CraftingInput input, HolderLookup.Provider registries) {
        SkyData.RecipeDef r = SkyRecipes.find(input);
        return r == null ? ItemStack.EMPTY : SkyItems.create(r.id, r.count);
    }

    public boolean canCraftInDimensions(int width, int height) {
        return true;
    }

    public ItemStack getResultItem(HolderLookup.Provider registries) {
        return ItemStack.EMPTY;
    }

    public RecipeSerializer<?> getSerializer() {
        return SkyRecipes.SIZED.get();
    }

    public CraftingBookCategory category() {
        return CraftingBookCategory.MISC;
    }

    public boolean isSpecial() {
        return true; // hidden from the recipe book
    }

    public boolean isIncomplete() {
        return false;
    }

    /** Vanilla takes 1 item per slot; here we take the rest of the required amount from the live stacks. */
    public NonNullList<ItemStack> getRemainingItems(CraftingInput input) {
        NonNullList<ItemStack> out = NonNullList.withSize(input.size(), ItemStack.EMPTY);
        SkyData.RecipeDef r = SkyRecipes.find(input);
        if (r != null) {
            int w = input.width();
            for (int y = 0; y < input.height(); y++) {
                for (int x = 0; x < w; x++) {
                    SkyData.Ing ing = SkyRecipes.ingAt(r, x, y);
                    ItemStack st = input.getItem(x + y * w);
                    if (ing != null && ing.count > 1 && !st.isEmpty()) st.shrink(ing.count - 1);
                }
            }
        }
        return out;
    }

    public static class Serializer implements RecipeSerializer<SkyCraftRecipe> {
        private static final SkyCraftRecipe INSTANCE = new SkyCraftRecipe();
        private static final MapCodec<SkyCraftRecipe> CODEC = MapCodec.unit(INSTANCE);
        private static final StreamCodec<RegistryFriendlyByteBuf, SkyCraftRecipe> STREAM = StreamCodec.unit(INSTANCE);

        public MapCodec<SkyCraftRecipe> codec() {
            return CODEC;
        }

        public StreamCodec<RegistryFriendlyByteBuf, SkyCraftRecipe> streamCodec() {
            return STREAM;
        }
    }
}
