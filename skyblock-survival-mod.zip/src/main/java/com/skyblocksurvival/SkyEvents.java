package com.skyblocksurvival;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

import static com.skyblocksurvival.SkyItems.fmt;

/**
 * Real Skyblock numbers are kept in the entity's persistent data.
 * Vanilla health is only a mirror (players: 20 HP = 100% of Skyblock health,
 * mobs: 1000 HP = 100%), so huge values never overflow vanilla limits.
 */
@EventBusSubscriber(modid = SkyMod.MODID)
public final class SkyEvents {
    private static final float MOB_VANILLA_HP = 1000f;
    private static final double UNLISTED_DIVISOR = 10.0; // damage divider for mobs not in mobs.json

    // ---------- mobs get Skyblock stats when they spawn ----------
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide()) return;
        if (!(e.getEntity() instanceof LivingEntity mob) || mob instanceof Player) return;
        CompoundTag t = mob.getPersistentData();
        if (t.contains("sb_max")) return;

        String key = BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType()).toString();
        SkyData.MobDef def = SkyData.MOBS.get(key);
        if (def == null) return;

        t.putDouble("sb_max", def.health);
        t.putDouble("sb_hp", def.health);
        t.putDouble("sb_dmg", def.damage);
        t.putDouble("sb_def", def.defense);
        t.putInt("sb_lvl", def.level);
        t.putString("sb_name", def.name);

        AttributeInstance hp = mob.getAttribute(Attributes.MAX_HEALTH);
        if (hp != null) {
            hp.setBaseValue(MOB_VANILLA_HP);
            mob.setHealth(MOB_VANILLA_HP);
        }
        updateName(mob);
    }

    private static void updateName(LivingEntity mob) {
        CompoundTag t = mob.getPersistentData();
        MutableComponent c = Component.literal("[Lv" + t.getInt("sb_lvl") + "] ").withStyle(ChatFormatting.GRAY)
                .append(Component.literal(t.getString("sb_name") + " ").withStyle(ChatFormatting.RED))
                .append(Component.literal(fmt(Math.ceil(t.getDouble("sb_hp"))) + "/" + fmt(t.getDouble("sb_max")))
                        .withStyle(ChatFormatting.GREEN))
                .append(Component.literal("\u2764").withStyle(ChatFormatting.RED));
        mob.setCustomName(c);
        mob.setCustomNameVisible(true);
    }

    // ---------- damage ----------
    @SubscribeEvent
    public static void onIncoming(LivingIncomingDamageEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim.level().isClientSide()) return;
        DamageSource src = e.getSource();
        Entity attacker = src.getEntity();

        // Skyblock mob hits a player
        if (victim instanceof Player p) {
            if (attacker != null && !(attacker instanceof Player)
                    && attacker.getPersistentData().contains("sb_dmg")) {
                PlayerStats s = PlayerStats.of(p);
                double raw = attacker.getPersistentData().getDouble("sb_dmg");
                double dealt = raw * 100.0 / (100.0 + s.defense);
                e.setAmount((float) (dealt / s.health * 20.0));
            }
            return; // fall / fire / etc. stay vanilla (percentage based)
        }

        // Player melee hit on a mob
        if (attacker instanceof Player p && src.getDirectEntity() == p) {
            long now = p.level().getGameTime();
            CompoundTag pd = p.getPersistentData();
            if (now - pd.getLong("sb_last_hit") < 4) { // max ~5 hits per second, also stops sweep
                e.setCanceled(true);
                return;
            }
            pd.putLong("sb_last_hit", now);

            PlayerStats s = PlayerStats.of(p);
            double dmg = (5 + s.weaponDamage + s.strength / 5.0) * (1 + s.strength / 100.0);
            if (p.getRandom().nextDouble() * 100.0 < s.critChance) dmg *= 1 + s.critDamage / 100.0;

            CompoundTag t = victim.getPersistentData();
            if (t.contains("sb_max")) {
                dmg *= 100.0 / (100.0 + t.getDouble("sb_def"));
                double hp = Math.max(0, t.getDouble("sb_hp") - dmg);
                t.putDouble("sb_hp", hp);
                float target = (float) (hp / t.getDouble("sb_max") * MOB_VANILLA_HP);
                float amount = hp <= 0 ? victim.getHealth() + 100f
                        : Math.max(victim.getHealth() - target, 0.001f);
                victim.invulnerableTime = 0;
                e.setAmount(amount);
                updateName(victim);
            } else {
                e.setAmount((float) (dmg / UNLISTED_DIVISOR));
            }
        }
    }

    // ---------- action bar: health / defense / strength ----------
    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post e) {
        Player p = e.getEntity();
        if (p.level().isClientSide() || p.tickCount % 10 != 0) return;
        PlayerStats s = PlayerStats.of(p);
        double hp = Math.ceil(p.getHealth() / p.getMaxHealth() * s.health);
        MutableComponent bar = Component.literal("\u2764 " + fmt(hp) + "/" + fmt(s.health) + "    ")
                .withStyle(ChatFormatting.RED)
                .append(Component.literal("\u2748 " + fmt(s.defense) + "    ").withStyle(ChatFormatting.GREEN))
                .append(Component.literal("\u2741 " + fmt(s.strength)).withStyle(ChatFormatting.RED));
        p.displayClientMessage(bar, true);
    }

    // ---------- commands ----------
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("sbgive")
                .requires(s -> s.hasPermission(2))
                .then(Commands.argument("id", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(SkyData.ITEMS.keySet(), b))
                        .executes(c -> give(c.getSource(), StringArgumentType.getString(c, "id")))));

        e.getDispatcher().register(Commands.literal("sbreload")
                .requires(s -> s.hasPermission(2))
                .executes(c -> {
                    SkyData.load();
                    c.getSource().sendSuccess(() -> Component.literal("Skyblock Survival: configs reloaded"), true);
                    return 1;
                }));
    }

    private static int give(CommandSourceStack src, String id) throws CommandSyntaxException {
        SkyData.ItemDef d = SkyData.ITEMS.get(id);
        if (d == null) {
            src.sendFailure(Component.literal("Unknown item: " + id));
            return 0;
        }
        ServerPlayer pl = src.getPlayerOrException();
        ItemStack st = SkyItems.create(id, d);
        if (!pl.getInventory().add(st)) pl.drop(st, false);
        return 1;
    }
}
