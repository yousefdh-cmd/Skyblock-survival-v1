package com.skyblocksurvival;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.damagesource.DamageContainer;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.entity.living.LivingExperienceDropEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

import java.util.ArrayList;
import java.util.List;

import static com.skyblocksurvival.SkyData.fmt;

/**
 * Real Skyblock numbers are stored in the mob's persistent data. Vanilla health is only a mirror:
 * players 20 HP = 100% of Skyblock health, mobs 1000 HP = 100%, so big numbers never overflow vanilla limits.
 */
@EventBusSubscriber(modid = SkyMod.MODID)
public final class SkyEvents {
    static final float MOB_HP = 1000f;

    // ------------------------------------------------------------------ mobs get level + stats
    static int rollLevel(RandomSource r) {
        SkyData.Config c = SkyData.CONFIG;
        if (c.force_level > 0) return Math.min(999, c.force_level);
        double total = 0;
        for (SkyData.Bracket b : c.level_brackets) total += Math.max(0, b.weight);
        if (total <= 0) return 1;
        double x = r.nextDouble() * total;
        for (SkyData.Bracket b : c.level_brackets) {
            x -= Math.max(0, b.weight);
            if (x < 0) {
                int lo = Math.max(1, b.min), hi = Math.min(999, Math.max(b.min, b.max));
                return lo + r.nextInt(hi - lo + 1);
            }
        }
        return 1;
    }

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide()) return;
        if (e.getEntity() instanceof ItemEntity ie) {
            // a broken Hyper Furnace drops as a renamed furnace: turn it back into the real item
            ItemStack dropped = ie.getItem();
            if (dropped.is(Items.FURNACE) && SkyItems.sbId(dropped) == null
                    && SkyItems.isHyperName(dropped.get(DataComponents.CUSTOM_NAME))) {
                ie.setItem(SkyItems.create("hyper_furnace", dropped.getCount()));
            }
            return;
        }
        if (!(e.getEntity() instanceof LivingEntity mob) || mob instanceof Player || mob instanceof ArmorStand) return;
        CompoundTag t = mob.getPersistentData();
        if (t.contains("sb_max")) return;
        AttributeInstance hpAttr = mob.getAttribute(Attributes.MAX_HEALTH);
        if (hpAttr == null) return;

        SkyData.Config c = SkyData.CONFIG;
        String key = BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType()).toString();
        SkyData.MobBase b = SkyData.MOBS.get(key);
        double vmax = Math.max(1.0, mob.getMaxHealth());

        double baseHp = (b != null && b.health > 0) ? b.health : vmax * c.fallback_health_multiplier;
        double baseDmg;
        if (b != null && b.damage >= 0) {
            baseDmg = b.damage;
        } else {
            AttributeInstance atk = mob.getAttribute(Attributes.ATTACK_DAMAGE);
            if (atk != null) baseDmg = atk.getValue() * c.fallback_damage_multiplier;
            else baseDmg = (mob instanceof Enemy) ? c.fallback_hostile_damage : 0;
        }
        double baseDef = b != null ? b.defense : 0;

        int lvl = rollLevel(mob.getRandom());
        double k = lvl - 1;
        t.putInt("sb_lvl", lvl);
        t.putDouble("sb_max", baseHp * (1 + k * c.mob_health_per_level));
        t.putDouble("sb_dmg", baseDmg * (1 + k * c.mob_damage_per_level));
        t.putDouble("sb_def", baseDef + k * c.mob_defense_per_level);
        t.putDouble("sb_vmax", vmax);

        hpAttr.setBaseValue(MOB_HP);
        mob.setHealth(MOB_HP);
        updateName(mob);
    }

    private static ChatFormatting levelColor(int lvl) {
        if (lvl >= 900) return ChatFormatting.DARK_RED;
        if (lvl >= 500) return ChatFormatting.RED;
        if (lvl >= 100) return ChatFormatting.GOLD;
        if (lvl >= 50) return ChatFormatting.YELLOW;
        return ChatFormatting.GRAY;
    }

    static void updateName(LivingEntity mob) {
        CompoundTag t = mob.getPersistentData();
        double max = t.getDouble("sb_max");
        double hp = Math.max(0, Math.ceil(mob.getHealth() / MOB_HP * max));
        int lvl = t.getInt("sb_lvl");
        MutableComponent name = Component.literal("[Lv" + lvl + "] ").withStyle(levelColor(lvl))
                .append(mob.getType().getDescription().copy().withStyle(ChatFormatting.RED))
                .append(Component.literal(" " + fmt(hp) + "/" + fmt(max)).withStyle(ChatFormatting.GREEN))
                .append(Component.literal("\u2764").withStyle(ChatFormatting.RED));
        mob.setCustomName(name);
        mob.setCustomNameVisible(true);
    }

    @SubscribeEvent
    public static void onDamaged(LivingDamageEvent.Post e) {
        LivingEntity v = e.getEntity();
        if (!v.level().isClientSide() && v.getPersistentData().contains("sb_max")) updateName(v);
    }

    // ------------------------------------------------------------------ damage
    private static boolean isSb(Entity en) {
        return en != null && en.getPersistentData().contains("sb_max");
    }

    private static void zeroVanillaReductions(LivingIncomingDamageEvent e) {
        e.addReductionModifier(DamageContainer.Reduction.ARMOR, (ct, r) -> 0f);
        e.addReductionModifier(DamageContainer.Reduction.ENCHANTMENTS, (ct, r) -> 0f);
    }

    /** raw = Skyblock damage before the victim's defense. */
    private static void applyToMob(LivingIncomingDamageEvent e, LivingEntity victim, double raw, double defMult) {
        CompoundTag t = victim.getPersistentData();
        double max = Math.max(1, t.getDouble("sb_max"));
        double dealt = raw * 100.0 / (100.0 + t.getDouble("sb_def") * defMult);
        double amt = dealt / max * MOB_HP;
        float cur = victim.getHealth();
        if (cur - amt < 0.5) amt = cur + 1; // finish off rounding leftovers
        victim.invulnerableTime = 0;
        e.setAmount((float) amt);
        zeroVanillaReductions(e);
    }

    @SubscribeEvent
    public static void onIncoming(LivingIncomingDamageEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim.level().isClientSide()) return;
        DamageSource src = e.getSource();
        if (src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return; // /kill, void
        Entity attacker = src.getEntity();
        Entity direct = src.getDirectEntity();
        SkyData.Config c = SkyData.CONFIG;

        // ---------- a player is hurt ----------
        if (victim instanceof Player pv) {
            PlayerStats s = PlayerStats.of(pv);
            boolean mobHit = attacker != null && !(attacker instanceof Player) && attacker.getPersistentData().contains("sb_dmg");
            SkyHurtEvent hurt = new SkyHurtEvent(pv, src, mobHit, s.defense, s.trueDefense);
            NeoForge.EVENT_BUS.post(hurt); // add-ons (armor enchantments) change the defense for this hit
            if (mobHit) {
                double raw = attacker.getPersistentData().getDouble("sb_dmg");
                if (src.is(DamageTypeTags.IS_EXPLOSION)) {
                    raw *= Math.min(1.0, e.getAmount() / c.explosion_reference_damage);
                }
                double dealt = raw * 100.0 / (100.0 + hurt.defense);
                e.setAmount((float) (dealt / s.health * pv.getMaxHealth()));
                zeroVanillaReductions(e);
            } else {
                e.setAmount((float) (e.getAmount() * 100.0 / (100.0 + hurt.trueDefense)));
            }
            return;
        }

        // ---------- a player hits a mob (melee or projectile) ----------
        if (attacker instanceof Player p && (direct == p || direct instanceof Projectile)) {
            boolean melee = direct == p;
            PlayerStats s = PlayerStats.of(p);
            CompoundTag pd = p.getPersistentData();

            if (melee) {
                long now = p.level().getGameTime();
                int cd = Math.max(1, (int) Math.round(s.cooldown * 100.0 / (100.0 + s.attackSpeed)));
                if (now - pd.getLong("sb_last_hit") < cd) { // also stops sweep attacks
                    e.setCanceled(true);
                    return;
                }
                pd.putLong("sb_last_hit", now);
            }

            double weapon;
            if (melee) {
                weapon = s.weaponDamage;
                if (s.weaponId.equals("minecraft:mace") && p.fallDistance > 1.5f) {
                    weapon += p.fallDistance * c.mace_bonus_per_block;
                }
            } else {
                weapon = s.rangedDamage;
                if (direct instanceof ThrownTrident || weapon <= 0) {
                    SkyData.WeaponDef w = SkyData.WEAPONS.get(direct instanceof ThrownTrident ? "minecraft:trident" : "minecraft:bow");
                    if (w != null) weapon = w.ranged_damage >= 0 ? w.ranged_damage : w.damage;
                }
                double speed = direct.getDeltaMovement().length();
                weapon *= Math.min(1.0, speed / c.projectile_full_speed);
            }

            double dmg = (5 + weapon + s.strength / 5.0) * (1 + s.strength / 100.0);
            boolean crit = p.getRandom().nextDouble() * 100.0 < s.critChance;
            if (crit) dmg *= 1 + s.critDamage / 100.0;
            int extraHits = (int) Math.floor(s.ferocity / 100.0);
            if (p.getRandom().nextDouble() * 100.0 < (s.ferocity % 100.0)) extraHits++;
            dmg *= 1 + extraHits;

            SkyHitEvent hit = new SkyHitEvent(p, victim, melee, crit, s, dmg);
            NeoForge.EVENT_BUS.post(hit); // add-ons (weapon enchantments) change the damage here
            dmg = hit.damage;

            if (isSb(victim)) applyToMob(e, victim, dmg, hit.defenseMultiplier);
            else e.setAmount((float) (dmg / 10.0));
            return;
        }

        // ---------- everything else hurting a Skyblock mob ----------
        if (isSb(victim)) {
            if (attacker != null && attacker.getPersistentData().contains("sb_dmg")) {
                double raw = attacker.getPersistentData().getDouble("sb_dmg");
                if (src.is(DamageTypeTags.IS_EXPLOSION)) raw *= Math.min(1.0, e.getAmount() / c.explosion_reference_damage);
                applyToMob(e, victim, raw, 1.0);
            } else {
                // fall, fire, lava... keep vanilla percentage of health
                double vmax = Math.max(1.0, victim.getPersistentData().getDouble("sb_vmax"));
                e.setAmount((float) (e.getAmount() * MOB_HP / vmax));
            }
        }
    }

    // ------------------------------------------------------------------ rewards
    @SubscribeEvent
    public static void onXp(LivingExperienceDropEvent e) {
        CompoundTag t = e.getEntity().getPersistentData();
        if (!t.contains("sb_lvl")) return;
        double m = 1 + (t.getInt("sb_lvl") - 1) * SkyData.CONFIG.xp_per_level;
        long xp = Math.round(e.getDroppedExperience() * m);
        e.setDroppedExperience((int) Math.min(1_000_000L, xp));
    }

    @SubscribeEvent
    public static void onDrops(LivingDropsEvent e) {
        LivingEntity v = e.getEntity();
        CompoundTag t = v.getPersistentData();
        if (!t.contains("sb_lvl") || v.level().isClientSide()) return;

        double mult = 1 + (SkyData.CONFIG.drop_multiplier_max - 1) * (t.getInt("sb_lvl") - 1) / 998.0;
        if (e.getSource().getEntity() instanceof Player p) mult *= 1 + PlayerStats.of(p).magicFind / 100.0;
        if (mult <= 1.0) return;

        List<ItemEntity> extra = new ArrayList<>();
        for (ItemEntity ie : e.getDrops()) {
            ItemStack st = ie.getItem();
            if (st.getMaxStackSize() <= 1) continue; // never duplicate armor/tools
            double add = st.getCount() * (mult - 1);
            int n = (int) Math.floor(add);
            if (v.getRandom().nextDouble() < add - n) n++;
            while (n > 0) {
                int k = Math.min(n, st.getMaxStackSize());
                extra.add(new ItemEntity(v.level(), ie.getX(), ie.getY(), ie.getZ(), st.copyWithCount(k)));
                n -= k;
            }
        }
        e.getDrops().addAll(extra);
    }

    // ------------------------------------------------------------------ regen + action bar
    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post e) {
        Player p = e.getEntity();
        if (p.level().isClientSide()) return;
        int tc = p.tickCount;
        if (tc % 10 != 0) return;

        SkyData.Config c = SkyData.CONFIG;
        PlayerStats s = PlayerStats.of(p);
        CompoundTag pd = p.getPersistentData();


        double mana = pd.contains("sb_mana") ? pd.getDouble("sb_mana") : s.intelligence;

        if (tc % 20 == 0) {
            if (p.isAlive() && p.getHealth() < p.getMaxHealth()) {
                p.heal((float) (p.getMaxHealth() * c.health_regen_percent_per_second / 100.0 * s.healthRegen / 100.0));
            }
            mana += s.intelligence * c.mana_regen_percent_per_second / 100.0;
        }
        mana = Math.min(s.intelligence, mana);
        pd.putDouble("sb_mana", mana);

        double hp = Math.ceil(p.getHealth() / p.getMaxHealth() * s.health);
        MutableComponent bar = Component.literal("\u2764 " + fmt(hp) + "/" + fmt(s.health) + "    ")
                .withStyle(ChatFormatting.RED)
                .append(Component.literal("\u2748 " + fmt(s.defense) + "    ").withStyle(ChatFormatting.GREEN))
                .append(Component.literal("\u270E " + fmt(Math.floor(mana)) + "/" + fmt(s.intelligence))
                        .withStyle(ChatFormatting.AQUA));
        p.displayClientMessage(bar, true);
    }
}
