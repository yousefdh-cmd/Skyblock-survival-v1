package com.skyblocksurvival;

import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.Event;

/** Posted every time a player's stats are computed. Add-ons change {@link #stats} directly. */
public class SkyStatsEvent extends Event {
    public final Player player;
    public final PlayerStats stats;

    public SkyStatsEvent(Player player, PlayerStats stats) {
        this.player = player;
        this.stats = stats;
    }
}
