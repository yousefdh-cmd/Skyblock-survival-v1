package com.skyblocksurvival;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.component.Unbreakable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class SkyItems {
    public static CompoundTag tag(ItemStack st) {
        if (st.isEmpty()) return null;
        CustomData cd = st.get(DataComponents.CUSTOM_DATA);
        return cd == null ? null : cd.copyTag();
    }

    public static ChatFormatting rarityColor(String r) {
        return switch (r.toUpperCase(Locale.ROOT)) {
            case "UNCOMMON" -> ChatFormatting.GREEN;
            case "RARE" -> ChatFormatting.BLUE;
            case "EPIC" -> ChatFormatting.DARK_PURPLE;
            case "LEGENDARY" -> ChatFormatting.GOLD;
            case "MYTHIC" -> ChatFormatting.LIGHT_PURPLE;
            case "DIVINE" -> ChatFormatting.AQUA;
            default -> ChatFormatting.WHITE;
        };
    }

    public static String fmt(double v) {
        return v == Math.rint(v) ? String.format(Locale.US, "%,.0f", v) : String.format(Locale.US, "%,.1f", v);
    }

    private static MutableComponent plain(String s, ChatFormatting c) {
        return Component.literal(s).setStyle(Style.EMPTY.withColor(c).withItalic(false));
    }

    private static void stat(List<Component> out, String label, double v, ChatFormatting c) {
        if (v == 0) return;
        out.add(plain(label + ": ", ChatFormatting.GRAY)
                .append(Component.literal("+" + fmt(v)).withStyle(c)));
    }

    public static ItemStack create(String id, SkyData.ItemDef d) {
        Item item = BuiltInRegistries.ITEM.get(ResourceLocation.parse(d.base));
        ItemStack st = new ItemStack(item);

        CompoundTag t = new CompoundTag();
        t.putString("sb_id", id);
        t.putString("sb_type", d.type);
        t.putDouble("damage", d.damage);
        t.putDouble("strength", d.strength);
        t.putDouble("crit_chance", d.crit_chance);
        t.putDouble("crit_damage", d.crit_damage);
        t.putDouble("health", d.health);
        t.putDouble("defense", d.defense);
        t.putDouble("intelligence", d.intelligence);
        st.set(DataComponents.CUSTOM_DATA, CustomData.of(t));

        ChatFormatting color = rarityColor(d.rarity);
        st.set(DataComponents.CUSTOM_NAME, plain(d.name, color));
        st.set(DataComponents.ATTRIBUTE_MODIFIERS, ItemAttributeModifiers.EMPTY);
        st.set(DataComponents.UNBREAKABLE, new Unbreakable(false));

        List<Component> lore = new ArrayList<>();
        stat(lore, "Damage", d.damage, ChatFormatting.RED);
        stat(lore, "Strength", d.strength, ChatFormatting.RED);
        stat(lore, "Crit Chance", d.crit_chance, ChatFormatting.BLUE);
        stat(lore, "Crit Damage", d.crit_damage, ChatFormatting.BLUE);
        stat(lore, "Health", d.health, ChatFormatting.GREEN);
        stat(lore, "Defense", d.defense, ChatFormatting.GREEN);
        stat(lore, "Intelligence", d.intelligence, ChatFormatting.AQUA);
        if (!d.lore.isEmpty()) {
            lore.add(Component.empty());
            for (String line : d.lore) lore.add(plain(line, ChatFormatting.GRAY));
        }
        lore.add(Component.empty());
        String kind = d.type.equalsIgnoreCase("armor") ? "ARMOR" : "WEAPON";
        lore.add(plain(d.rarity.toUpperCase(Locale.ROOT) + " " + kind, color).withStyle(ChatFormatting.BOLD));
        st.set(DataComponents.LORE, new ItemLore(lore));
        return st;
    }
}
