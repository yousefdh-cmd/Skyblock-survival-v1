package com.skyblocksurvival;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;

import java.util.List;
import java.util.Locale;

/** Enchanted items: a vanilla item (same model) + custom data, name, glint and Skyblock lore. */
public final class SkyItems {

    /** Skyblock id of the stack (e.g. "enchanted_coal") or null for a normal item. */
    public static String sbId(ItemStack st) {
        if (st.isEmpty()) return null;
        CustomData cd = st.get(DataComponents.CUSTOM_DATA);
        if (cd == null) return null;
        CompoundTag t = cd.copyTag();
        return t.contains("sb_id") ? t.getString("sb_id") : null;
    }

    private static MutableComponent plain(String s, ChatFormatting c) {
        return Component.literal(s).setStyle(Style.EMPTY.withColor(c).withItalic(false));
    }

    public static ItemStack create(String id, int count) {
        SkyData.EnchDef d = SkyData.ENCHANTED.get(id);
        if (d == null) return ItemStack.EMPTY;
        Item item = BuiltInRegistries.ITEM.get(ResourceLocation.parse(d.base));
        if (item == Items.AIR) return ItemStack.EMPTY;

        ItemStack st = new ItemStack(item, Math.max(1, Math.min(count, item.getDefaultMaxStackSize())));
        CompoundTag t = new CompoundTag();
        t.putString("sb_id", id);
        st.set(DataComponents.CUSTOM_DATA, CustomData.of(t));

        ChatFormatting color = SkyData.rarityColor(d.rarity);
        st.set(DataComponents.CUSTOM_NAME, plain(d.name, color));
        st.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, Boolean.TRUE);
        st.set(DataComponents.LORE, new ItemLore(List.of(
                plain(d.rarity.toUpperCase(Locale.ROOT), color).withStyle(ChatFormatting.BOLD))));
        return st;
    }
}
