package com.skyblocksurvival;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.Event;

/** Posted when a player is hurt. Add-ons change {@link #defense} / {@link #trueDefense} for this one hit. */
public class SkyHurtEvent extends Event {
    public final Player player;
    public final DamageSource source;
    public final boolean mobHit; // true = hit by a Skyblock mob, false = fall, fire, lava...
    public double defense;
    public double trueDefense;

    public SkyHurtEvent(Player player, DamageSource source, boolean mobHit, double defense, double trueDefense) {
        this.player = player;
        this.source = source;
        this.mobHit = mobHit;
        this.defense = defense;
        this.trueDefense = trueDefense;
    }
}
