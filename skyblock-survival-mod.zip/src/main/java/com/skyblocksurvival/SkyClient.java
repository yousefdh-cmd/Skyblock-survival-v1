package com.skyblocksurvival;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.skyblocksurvival.SkyData.fmt;

/** Rewrites the tooltip of vanilla weapons, tools and armor so it looks like Hypixel Skyblock. */
@EventBusSubscriber(modid = SkyMod.MODID, value = Dist.CLIENT)
public final class SkyClient {

    private static Component stat(String label, String value, ChatFormatting color) {
        return Component.literal(label).withStyle(ChatFormatting.GRAY)
                .append(Component.literal(value).withStyle(color));
    }

    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent e) {
        ItemStack st = e.getItemStack();
        String id = PlayerStats.key(st);
        SkyData.WeaponDef w = SkyData.WEAPONS.get(id);
        SkyData.ArmorDef a = SkyData.ARMOR.get(id);
        if (w == null && a == null) return; // every other item keeps its normal tooltip
        List<Component> tt = e.getToolTip();
        if (tt.isEmpty()) return;

        String rarity = SkyData.rarityOf(id, w != null ? w.rarity : a.rarity);
        ChatFormatting color = SkyData.rarityColor(rarity);

        List<Component> out = new ArrayList<>();
        out.add(tt.get(0).copy().withStyle(color)); // item name in rarity color

        List<Component> custom = SkyApi.ENCHANT_LINES != null ? SkyApi.ENCHANT_LINES.apply(st) : null;
        if (custom != null) {
            out.addAll(custom);
        } else {
            int enchants = st.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY).size();
            for (int i = 1; i <= enchants && i < tt.size(); i++) {
                out.add(tt.get(i).copy().withStyle(ChatFormatting.BLUE));
            }
        }

        if (w != null) {
            double dmg = w.damage > 0 ? w.damage : w.ranged_damage;
            if (dmg > 0) out.add(stat("Damage: ", "+" + fmt(dmg), ChatFormatting.RED));
        }
        if (a != null) {
            if (a.defense > 0) out.add(stat("Defense: ", "+" + fmt(a.defense), ChatFormatting.GREEN));
            if (a.health > 0) out.add(stat("Health: ", "+" + fmt(a.health), ChatFormatting.GREEN));
        }

        out.add(Component.empty());
        out.add(Component.literal("This item can be reforged!").withStyle(ChatFormatting.GRAY));
        String path = id.substring(id.indexOf(':') + 1);
        String type = path.substring(path.lastIndexOf('_') + 1).toUpperCase(Locale.ROOT);
        out.add(Component.literal(rarity + " " + type).withStyle(color).withStyle(ChatFormatting.BOLD));

        tt.clear();
        tt.addAll(out);
    }
}
