package com.skyblocksurvival;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.Event;

/** Posted when a player hits a mob, before defense is applied. Add-ons change {@link #damage}. */
public class SkyHitEvent extends Event {
    public final Player attacker;
    public final LivingEntity victim;
    public final boolean melee;
    public final boolean crit;
    public final PlayerStats stats;
    public double damage;
    public double defenseMultiplier = 1.0; // 0.9 = the victim's defense counts 10% less

    public SkyHitEvent(Player attacker, LivingEntity victim, boolean melee, boolean crit, PlayerStats stats, double damage) {
        this.attacker = attacker;
        this.victim = victim;
        this.melee = melee;
        this.crit = crit;
        this.stats = stats;
        this.damage = damage;
    }
}
