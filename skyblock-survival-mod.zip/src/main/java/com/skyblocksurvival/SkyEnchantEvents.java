package com.skyblocksurvival;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.RecipeBookMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/** Enchanted items are materials only: they cannot be eaten, thrown, placed, or used in vanilla recipes. */
@EventBusSubscriber(modid = SkyMod.MODID)
public final class SkyEnchantEvents {

    @SubscribeEvent
    public static void onUse(PlayerInteractEvent.RightClickItem e) {
        if (SkyItems.sbId(e.getItemStack()) != null) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onEntityUse(PlayerInteractEvent.EntityInteract e) {
        if (SkyItems.sbId(e.getItemStack()) != null) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent e) {
        if (!(e.getEntity() instanceof LivingEntity le)) return;
        Item placed = e.getPlacedBlock().getBlock().asItem();
        ItemStack main = le.getMainHandItem();
        ItemStack off = le.getOffhandItem();
        if ((SkyItems.sbId(main) != null && main.getItem() == placed)
                || (SkyItems.sbId(off) != null && off.getItem() == placed)) {
            e.setCanceled(true);
        }
    }

    /** A vanilla recipe must never accept an enchanted item as if it were the normal one. */
    @SubscribeEvent
    public static void onTick(PlayerTickEvent.Post e) {
        Player p = e.getEntity();
        if (p.level().isClientSide()) return;
        if (!(p.containerMenu instanceof RecipeBookMenu<?, ?> rb)) return;
        Slot result = rb.getSlot(rb.getResultSlotIndex());
        ItemStack res = result.getItem();
        if (res.isEmpty() || SkyItems.sbId(res) != null) return;
        for (int i = 1; i < rb.getSize(); i++) {
            if (SkyItems.sbId(rb.getSlot(i).getItem()) != null) {
                result.set(ItemStack.EMPTY);
                rb.broadcastChanges();
                return;
            }
        }
    }
}
