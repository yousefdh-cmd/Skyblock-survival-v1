package com.skyblocksurvival;

import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import static com.skyblocksurvival.SkyData.fmt;

@EventBusSubscriber(modid = SkyMod.MODID)
public final class SkyCommands {

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("sbstats").executes(c -> {
            ServerPlayer p = c.getSource().getPlayerOrException();
            PlayerStats s = PlayerStats.of(p);
            line(c.getSource(), "\u2764 Health", s.health, ChatFormatting.RED);
            line(c.getSource(), "\u2748 Defense", s.defense, ChatFormatting.GREEN);
            line(c.getSource(), "True Defense", s.trueDefense, ChatFormatting.WHITE);
            line(c.getSource(), "\u2741 Strength", s.strength, ChatFormatting.RED);
            line(c.getSource(), "\u2623 Crit Chance", s.critChance, ChatFormatting.BLUE);
            line(c.getSource(), "\u2620 Crit Damage", s.critDamage, ChatFormatting.BLUE);
            line(c.getSource(), "\u2AFD Ferocity", s.ferocity, ChatFormatting.RED);
            line(c.getSource(), "\u2694 Bonus Attack Speed", s.attackSpeed, ChatFormatting.YELLOW);
            line(c.getSource(), "\u2726 Speed", s.speed, ChatFormatting.WHITE);
            line(c.getSource(), "\u270E Intelligence", s.intelligence, ChatFormatting.AQUA);
            line(c.getSource(), "\u0E51 Ability Damage", s.abilityDamage, ChatFormatting.RED);
            line(c.getSource(), "\u272F Magic Find", s.magicFind, ChatFormatting.AQUA);
            line(c.getSource(), "Weapon damage", s.weaponDamage, ChatFormatting.RED);
            return 1;
        }));

        e.getDispatcher().register(Commands.literal("sbreload")
                .requires(s -> s.hasPermission(2))
                .executes(c -> {
                    SkyData.load();
                    c.getSource().sendSuccess(() -> Component.literal("Skyblock Survival: configs reloaded"), true);
                    return 1;
                }));
    }

    private static void line(CommandSourceStack src, String label, double v, ChatFormatting color) {
        src.sendSuccess(() -> Component.literal(label + ": ").withStyle(ChatFormatting.GRAY)
                .append(Component.literal(fmt(v)).withStyle(color)), false);
    }
}
