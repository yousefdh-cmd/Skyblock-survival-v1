package com.skyblocksurvival;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

import java.util.ArrayList;
import java.util.Optional;

/** A furnace placed from the Hyper Furnace item smelts everything in its input slot instantly (no fuel needed). */
@EventBusSubscriber(modid = SkyMod.MODID)
public final class SkyHyperFurnace {

    @SubscribeEvent
    public static void onTick(PlayerTickEvent.Post e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (p.tickCount % 10 != 0) return;
        ServerLevel level = (ServerLevel) p.level();
        int cx = p.chunkPosition().x;
        int cz = p.chunkPosition().z;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(cx + dx, cz + dz);
                if (chunk == null) continue;
                for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
                    if (be instanceof AbstractFurnaceBlockEntity f && SkyItems.isHyperName(f.getCustomName())) {
                        smeltAll(level, f);
                    }
                }
            }
        }
    }

    private static void smeltAll(ServerLevel level, AbstractFurnaceBlockEntity f) {
        for (int i = 0; i < 64; i++) {
            ItemStack in = f.getItem(0);
            if (in.isEmpty()) return;
            SingleRecipeInput input = new SingleRecipeInput(in);
            Optional<RecipeHolder<SmeltingRecipe>> opt = level.getRecipeManager().getRecipeFor(RecipeType.SMELTING, input, level);
            if (opt.isEmpty()) return;
            RecipeHolder<SmeltingRecipe> holder = opt.get();
            ItemStack result = holder.value().assemble(input, level.registryAccess());
            if (result.isEmpty()) return;

            ItemStack out = f.getItem(2);
            if (out.isEmpty()) {
                f.setItem(2, result.copy());
            } else if (ItemStack.isSameItemSameComponents(out, result)
                    && out.getCount() + result.getCount() <= out.getMaxStackSize()) {
                out.grow(result.getCount());
            } else {
                return; // output full
            }
            in.shrink(1);
            if (in.isEmpty()) f.setItem(0, ItemStack.EMPTY);
            f.setRecipeUsed(holder);
            f.setChanged();
        }
    }
}
