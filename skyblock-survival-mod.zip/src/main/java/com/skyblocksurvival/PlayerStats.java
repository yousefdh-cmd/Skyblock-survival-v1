package com.skyblocksurvival;

import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.neoforged.neoforge.common.NeoForge;

/** Skyblock-style stats = base + XP level + the vanilla weapon in hand + worn vanilla armor + enchantments. */
public final class PlayerStats {
    public double health, defense, trueDefense, strength, critChance, critDamage, ferocity;
    public double attackSpeed, speed, intelligence, abilityDamage, magicFind;
    public double healthRegen = 100; // 100 = normal natural regeneration
    public double weaponDamage, rangedDamage;
    public int cooldown = 4;
    public int xpLevel;
    public String weaponId = "minecraft:air";

    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    public static String key(ItemStack st) {
        return BuiltInRegistries.ITEM.getKey(st.getItem()).toString();
    }

    public static int enchantLevel(ItemStack st, String path) {
        if (st.isEmpty()) return 0;
        ItemEnchantments ench = st.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);
        for (var en : ench.entrySet()) {
            boolean match = en.getKey().unwrapKey().map(k -> k.location().getPath().equals(path)).orElse(false);
            if (match) return en.getIntValue();
        }
        return 0;
    }

    public static PlayerStats of(Player p) {
        SkyData.Config c = SkyData.CONFIG;
        PlayerStats s = new PlayerStats();
        int lvl = p.experienceLevel;
        s.xpLevel = lvl;
        s.health = c.player_base_health + lvl * c.per_level_health;
        s.defense = c.player_base_defense + lvl * c.per_level_defense;
        s.trueDefense = c.player_base_true_defense + lvl * c.per_level_true_defense;
        s.strength = c.player_base_strength + lvl * c.per_level_strength;
        s.critChance = c.player_base_crit_chance;
        s.critDamage = c.player_base_crit_damage + lvl * c.per_level_crit_damage;
        s.ferocity = c.player_base_ferocity;
        s.attackSpeed = c.player_base_attack_speed;
        s.speed = c.player_base_speed;
        s.intelligence = c.player_base_intelligence + lvl * c.per_level_intelligence;
        s.abilityDamage = c.player_base_ability_damage;
        s.magicFind = c.player_base_magic_find + lvl * c.per_level_magic_find;
        s.cooldown = c.attack_cooldown_ticks_default;

        ItemStack hand = p.getMainHandItem();
        s.weaponId = key(hand);
        SkyData.WeaponDef w = SkyData.WEAPONS.get(s.weaponId);
        if (w != null) {
            s.weaponDamage = w.damage;
            s.rangedDamage = w.ranged_damage >= 0 ? w.ranged_damage : w.damage;
            s.cooldown = w.cooldown;
        }

        for (EquipmentSlot slot : ARMOR) {
            ItemStack st = p.getItemBySlot(slot);
            SkyData.ArmorDef a = SkyData.ARMOR.get(key(st));
            if (a == null) continue;
            s.defense += a.defense;
            s.health += a.health;
        }
        NeoForge.EVENT_BUS.post(new SkyStatsEvent(p, s)); // add-ons (enchantments...) adjust the stats here
        return s;
    }
}
