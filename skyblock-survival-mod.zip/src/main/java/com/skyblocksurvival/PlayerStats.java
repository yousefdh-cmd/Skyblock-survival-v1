package com.skyblocksurvival;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** Skyblock-style stats = base values + held weapon + worn armor. */
public final class PlayerStats {
    public double health = 100, defense = 0, strength = 0;
    public double critChance = 30, critDamage = 50, intelligence = 0;
    public double weaponDamage = 0;

    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    public static PlayerStats of(Player p) {
        PlayerStats s = new PlayerStats();
        s.add(p.getMainHandItem(), "weapon");
        for (EquipmentSlot slot : ARMOR) s.add(p.getItemBySlot(slot), "armor");
        return s;
    }

    private void add(ItemStack st, String type) {
        CompoundTag t = SkyItems.tag(st);
        if (t == null || !type.equals(t.getString("sb_type"))) return;
        weaponDamage += t.getDouble("damage");
        strength += t.getDouble("strength");
        critChance += t.getDouble("crit_chance");
        critDamage += t.getDouble("crit_damage");
        health += t.getDouble("health");
        defense += t.getDouble("defense");
        intelligence += t.getDouble("intelligence");
    }
}
