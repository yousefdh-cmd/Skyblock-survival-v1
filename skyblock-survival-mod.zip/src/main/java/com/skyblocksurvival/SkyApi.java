package com.skyblocksurvival;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.function.Function;

public final class SkyApi {
    /** Set by the enchantments add-on: builds the enchantment lines shown on weapons and armor. */
    public static Function<ItemStack, List<Component>> ENCHANT_LINES = null;

    private SkyApi() {}
}
