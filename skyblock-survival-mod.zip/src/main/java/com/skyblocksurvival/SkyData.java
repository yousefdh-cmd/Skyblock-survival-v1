package com.skyblocksurvival;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.ChatFormatting;
import net.neoforged.fml.loading.FMLPaths;

import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** All settings live in config/skyblocksurvival/*.json (created on first run). */
public final class SkyData {

    public static class Bracket {
        public int min = 1, max = 10;
        public double weight = 1;
        public Bracket() {}
        public Bracket(int min, int max, double weight) { this.min = min; this.max = max; this.weight = weight; }
    }

    public static class Config {
        // ---- mob levels ----
        public int force_level = 0;                  // 0 = random. Set 999 to test the rarest mobs, then /sbreload
        public List<Bracket> level_brackets = new ArrayList<>(List.of(
                new Bracket(1, 10, 60), new Bracket(11, 50, 22), new Bracket(51, 100, 10),
                new Bracket(101, 250, 5), new Bracket(251, 500, 2), new Bracket(501, 900, 0.9),
                new Bracket(901, 998, 0.09), new Bracket(999, 999, 0.01)));
        public double mob_health_per_level = 0.3;    // health x (1 + (level-1) * this)
        public double mob_damage_per_level = 0.1;
        public double mob_defense_per_level = 0.3;   // added defense per level
        // mobs that are not in mob_stats.json
        public double fallback_health_multiplier = 5;  // x vanilla max health
        public double fallback_damage_multiplier = 5;  // x vanilla attack damage
        public double fallback_hostile_damage = 20;    // hostile mobs without an attack-damage attribute (skeletons...)
        // ---- rewards ----
        public double xp_per_level = 0.25;           // xp x (1 + (level-1) * this)
        public double drop_multiplier_max = 20;      // drops at level 999 = x this (stackable items only)
        // ---- player base stats ----
        public double player_base_health = 100;
        public double player_base_defense = 0;
        public double player_base_true_defense = 0;
        public double player_base_strength = 0;
        public double player_base_crit_chance = 30;
        public double player_base_crit_damage = 50;
        public double player_base_ferocity = 0;
        public double player_base_attack_speed = 0;
        public double player_base_speed = 100;
        public double player_base_intelligence = 100;
        public double player_base_ability_damage = 0;
        public double player_base_magic_find = 0;
        // ---- gained per vanilla XP level of the player ----
        public double per_level_health = 5;
        public double per_level_defense = 1;
        public double per_level_true_defense = 0.1;
        public double per_level_strength = 1;
        public double per_level_crit_damage = 0.5;
        public double per_level_intelligence = 2;
        public double per_level_magic_find = 0.1;
        // ---- regeneration (percent of max per second) ----
        public double health_regen_percent_per_second = 1.0;
        public double mana_regen_percent_per_second = 2.0;
        // ---- enchantments ----
        public double sharpness_percent_per_level = 5;
        public double power_percent_per_level = 8;
        public double protection_defense_per_level = 3;
        // ---- combat ----
        public int attack_cooldown_ticks_default = 4;
        public double projectile_full_speed = 3.0;
        public double mace_bonus_per_block = 5;
        public double explosion_reference_damage = 20;
        // ---- Hyper Furnace ----
        public int hyper_furnace_interval_ticks = 5;   // how often it smelts (20 ticks = 1 second)
        public int hyper_furnace_radius_chunks = 3;    // works while a player is within this many chunks
    }

    public static class MobBase {
        public double health = -1, damage = -1, defense = 0; // -1 = automatic
    }

    public static class WeaponDef {
        public String rarity = null;      // COMMON UNCOMMON RARE EPIC LEGENDARY MYTHIC (null = automatic)
        public double damage = 0;
        public double ranged_damage = -1; // -1 = same as damage
        public int cooldown = 4;
    }

    public static class ArmorDef {
        public String rarity = null;
        public double defense = 0, health = 0;
    }

    public static class EnchDef {
        public String name = "Enchanted Item";
        public String base = "minecraft:stone";
        public String rarity = "UNCOMMON";
        public boolean glint = true;
        public List<String> lore = new ArrayList<>();
    }

    public static class Ing {
        public List<String> items = new ArrayList<>(); // "minecraft:cobblestone" or "sb:enchanted_coal"
        public int count = 1;                          // amount needed in that slot
    }

    public static class RecipeDef {
        public transient String id;
        public int count = 1;                          // how many items you get
        public List<String> pattern = new ArrayList<>();
        public Map<String, Ing> key = new HashMap<>();
        public String note;
    }

    public static Config CONFIG = new Config();
    public static final Map<String, MobBase> MOBS = new HashMap<>();
    public static final Map<String, WeaponDef> WEAPONS = new HashMap<>();
    public static final Map<String, ArmorDef> ARMOR = new HashMap<>();
    public static final Map<String, EnchDef> ENCHANTED = new LinkedHashMap<>();
    public static final Map<String, RecipeDef> RECIPES = new LinkedHashMap<>();

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static void load() {
        Path dir = FMLPaths.CONFIGDIR.get().resolve(SkyMod.MODID);
        try {
            Files.createDirectories(dir);
            Path cfg = dir.resolve("config.json");
            if (!Files.exists(cfg)) {
                try (Writer w = Files.newBufferedWriter(cfg)) { GSON.toJson(new Config(), w); }
            }
            try (Reader r = Files.newBufferedReader(cfg)) {
                Config c = GSON.fromJson(r, Config.class);
                CONFIG = c == null ? new Config() : c;
            }
        } catch (Exception e) {
            SkyMod.LOGGER.error("Could not read config.json", e);
            CONFIG = new Config();
        }
        fill(MOBS, read(dir, "mob_stats.json", new TypeToken<LinkedHashMap<String, MobBase>>() {}.getType()));
        fill(WEAPONS, read(dir, "weapons.json", new TypeToken<LinkedHashMap<String, WeaponDef>>() {}.getType()));
        fill(ARMOR, read(dir, "armor.json", new TypeToken<LinkedHashMap<String, ArmorDef>>() {}.getType()));
        fill(ENCHANTED, read(dir, "enchanted_items.json", new TypeToken<LinkedHashMap<String, EnchDef>>() {}.getType()));
        fill(RECIPES, read(dir, "recipes.json", new TypeToken<LinkedHashMap<String, RecipeDef>>() {}.getType()));
        RECIPES.entrySet().removeIf(en -> !ENCHANTED.containsKey(en.getKey()) || en.getValue() == null || en.getValue().pattern.isEmpty());
        for (Map.Entry<String, RecipeDef> en : RECIPES.entrySet()) {
            RecipeDef r = en.getValue();
            r.id = en.getKey();
            int w = 0;
            for (String row : r.pattern) w = Math.max(w, row.length());
            for (int i = 0; i < r.pattern.size(); i++) {
                StringBuilder sb = new StringBuilder(r.pattern.get(i));
                while (sb.length() < w) sb.append(' ');
                r.pattern.set(i, sb.toString());
            }
        }
        SkyMod.LOGGER.info("Skyblock Survival: {} mobs, {} weapons, {} armor pieces, {} enchanted items, {} recipes",
                MOBS.size(), WEAPONS.size(), ARMOR.size(), ENCHANTED.size(), RECIPES.size());
    }

    private static <T> void fill(Map<String, T> target, Map<String, T> src) {
        target.clear();
        if (src != null) target.putAll(src);
    }

    private static <T> T read(Path dir, String file, Type type) {
        Path p = dir.resolve(file);
        try {
            if (!Files.exists(p)) {
                try (InputStream in = SkyData.class.getResourceAsStream("/defaults/" + file)) {
                    if (in != null) Files.copy(in, p);
                }
            }
            try (Reader r = Files.newBufferedReader(p)) {
                return GSON.fromJson(r, type);
            }
        } catch (Exception e) {
            SkyMod.LOGGER.error("Could not read " + file, e);
            return null;
        }
    }

    public static String rarityOf(String id, String configured) {
        if (configured != null && !configured.isEmpty()) return configured.toUpperCase(Locale.ROOT);
        if (id.contains("netherite") || id.contains("trident")) return "RARE";
        if (id.contains("mace")) return "EPIC";
        if (id.contains("diamond") || id.contains("chainmail") || id.contains("turtle")) return "UNCOMMON";
        return "COMMON";
    }

    public static ChatFormatting rarityColor(String r) {
        return switch (r.toUpperCase(Locale.ROOT)) {
            case "UNCOMMON" -> ChatFormatting.GREEN;
            case "RARE" -> ChatFormatting.BLUE;
            case "EPIC" -> ChatFormatting.DARK_PURPLE;
            case "LEGENDARY" -> ChatFormatting.GOLD;
            case "MYTHIC" -> ChatFormatting.LIGHT_PURPLE;
            default -> ChatFormatting.WHITE;
        };
    }

    public static String fmt(double v) {
        return v == Math.rint(v) ? String.format(Locale.US, "%,.0f", v) : String.format(Locale.US, "%,.1f", v);
    }
}
