package com.skyblocksurvival;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.neoforged.fml.loading.FMLPaths;

import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Loads items.json and mobs.json from config/skyblocksurvival/ (created from defaults on first run). */
public final class SkyData {
    public static class ItemDef {
        public String base = "minecraft:iron_sword";
        public String name = "Unnamed";
        public String rarity = "COMMON";
        public String type = "weapon"; // weapon | armor
        public double damage, strength, crit_chance, crit_damage, health, defense, intelligence;
        public List<String> lore = new ArrayList<>();
    }

    public static class MobDef {
        public String name = "Mob";
        public int level = 1;
        public double health = 100, damage = 10, defense = 0;
    }

    public static final Map<String, ItemDef> ITEMS = new LinkedHashMap<>();
    public static final Map<String, MobDef> MOBS = new HashMap<>();
    private static final Gson GSON = new Gson();

    public static void load() {
        ITEMS.clear();
        MOBS.clear();
        Path dir = FMLPaths.CONFIGDIR.get().resolve(SkyMod.MODID);
        Map<String, ItemDef> items = read(dir, "items.json", new TypeToken<LinkedHashMap<String, ItemDef>>() {}.getType());
        Map<String, MobDef> mobs = read(dir, "mobs.json", new TypeToken<LinkedHashMap<String, MobDef>>() {}.getType());
        if (items != null) ITEMS.putAll(items);
        if (mobs != null) MOBS.putAll(mobs);
        SkyMod.LOGGER.info("Skyblock Survival loaded {} items, {} mobs", ITEMS.size(), MOBS.size());
    }

    private static <T> T read(Path dir, String file, Type type) {
        Path p = dir.resolve(file);
        try {
            Files.createDirectories(dir);
            if (!Files.exists(p)) {
                try (InputStream in = SkyData.class.getResourceAsStream("/defaults/" + file)) {
                    if (in != null) Files.copy(in, p);
                }
            }
            try (Reader r = Files.newBufferedReader(p)) {
                return GSON.fromJson(r, type);
            }
        } catch (Exception e) {
            SkyMod.LOGGER.error("Could not read " + file, e);
            return null;
        }
    }
}
