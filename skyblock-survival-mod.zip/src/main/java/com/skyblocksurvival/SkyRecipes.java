package com.skyblocksurvival;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Matching for Skyblock recipes (amounts per slot). Recipes themselves live in config/skyblocksurvival/recipes.json. */
public final class SkyRecipes {
    public static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS =
            DeferredRegister.create(Registries.RECIPE_SERIALIZER, SkyMod.MODID);
    public static final DeferredHolder<RecipeSerializer<?>, SkyCraftRecipe.Serializer> SIZED =
            SERIALIZERS.register("sized", SkyCraftRecipe.Serializer::new);

    static boolean ingOk(SkyData.Ing ing, ItemStack st) {
        if (st.isEmpty() || st.getCount() < ing.count) return false;
        String sb = SkyItems.sbId(st);
        String key = PlayerStats.key(st);
        for (String s : ing.items) {
            if (s.startsWith("sb:")) {
                if (s.substring(3).equals(sb)) return true;
            } else if (sb == null && s.equals(key)) {
                return true; // plain items only: enchanted ones never count as their base item
            }
        }
        return false;
    }

    public static SkyData.Ing ingAt(SkyData.RecipeDef r, int x, int y) {
        char c = r.pattern.get(y).charAt(x);
        if (c == ' ') return null;
        return r.key.get(String.valueOf(c));
    }

    public static boolean matches(SkyData.RecipeDef r, CraftingInput in) {
        int h = r.pattern.size();
        if (h == 0) return false;
        int w = r.pattern.get(0).length();
        if (in.width() != w || in.height() != h) return false;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                ItemStack st = in.getItem(x + y * w);
                SkyData.Ing ing = ingAt(r, x, y);
                if (ing == null) {
                    if (!st.isEmpty()) return false;
                } else if (!ingOk(ing, st)) {
                    return false;
                }
            }
        }
        return true;
    }

    public static SkyData.RecipeDef find(CraftingInput in) {
        for (SkyData.RecipeDef r : SkyData.RECIPES.values()) {
            if (matches(r, in)) return r;
        }
        return null;
    }
}
